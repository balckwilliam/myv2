
# vmess
_load vmess-config.sh

# ban domain
_load ban_xx.sh

# ban bt
_load ban_bt.sh

# ban ad
_load ban_ad.sh

# custom rules
_load custom_rules.sh

# ss
_load ss-config.sh

# socks
_load socks-config.sh

# mtproto
_load mtproto-config.sh

# custom config
_load custom_config.sh
